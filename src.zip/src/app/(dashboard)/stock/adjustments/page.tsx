'use client';
import { Settings } from 'lucide-react';

export default function GenericERPView() {
    return (
        <div style={{ padding: '24px', animation: 'fadeIn 0.5s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                <div>
                    <h1 style={{ fontSize: '24px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <span>⚖️</span> تسويات الجرد التعديلية
                    </h1>
                    <p style={{ color: 'var(--text-muted)', marginTop: '4px', fontSize: '14px' }}>
                        إثبات العجز والزيادة المخزنية وتسويتها محاسبياً في حسابات الأرباح والخسائر.
                    </p>
                </div>
                <button className="btn btn-primary" style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <span>إضافة مستند جديد</span>
                </button>
            </div>

            <div className="card" style={{ padding: '60px 20px', textAlign: 'center', background: 'var(--bg-card)' }}>
                <Settings size={48} style={{ opacity: 0.2, margin: '0 auto 16px auto', animation: 'spin 4s linear infinite' }} />
                <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '8px' }}>لم يتم العثور على سجلات بعد</h3>
                <p style={{ color: 'var(--text-muted)', fontSize: '14px', maxWidth: '400px', margin: '0 auto' }}>
                    هذه واجهة مركزية تمت إضافتها ضمن مطابقة دورة العمل המؤسسية (Oracle ERP Lifecycle). 
                    يمكنك البدء قريباً في إنشاء المستندات وربطها بالدورة المستندية تلقائياً.
                </p>
            </div>
        </div>
    );
}