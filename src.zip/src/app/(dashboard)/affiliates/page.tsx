﻿'use client';

import { useState, useEffect } from 'react';
import { useTranslation } from "@/lib/i18n";

export default function SaaS_Affiliate_Dashboard() {
    const { t } = useTranslation();
    const [referralLink, setReferralLink] = useState('');
    const [stats, setStats] = useState({ clicks: 0, signups: 0, earnings: 0 });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Fetch or simulate Affiliate Data binding
        setTimeout(() => {
            const mockUserId = "NAMA-POS-" + Math.floor(Math.random() * 9000 + 1000);
            setReferralLink(`https://n1.namainvist.com/onboarding/zatca?ref=${mockUserId}`);
            setStats({
                clicks: Math.floor(Math.random() * 150),
                signups: Math.floor(Math.random() * 12),
                earnings: Math.floor(Math.random() * 5000)
            });
            setLoading(false);
        }, 1200);
    }, []);

    const handleCopy = () => {
        navigator.clipboard.writeText(referralLink);
        alert(t('sys.str_287'));
    };

    return (
        <div style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto', fontFamily: 'Noto Sans Arabic, sans-serif' }} dir="rtl">
            
            {/* Header Section */}
            <div style={{ background: 'linear-gradient(135deg, #1e3a8a, #3b82f6)', borderRadius: '24px', padding: '40px', color: '#fff', display: 'flex', justifyContent: 'space-between', alignItems: 'center', boxShadow: '0 20px 40px rgba(59,130,246,0.3)' }}>
                <div>
                    <h1 style={{ fontSize: '36px', fontWeight: '900', margin: '0 0 16px 0' }}>{t('sys.str_276')}</h1>
                    <p style={{ fontSize: '18px', margin: 0, opacity: 0.9, maxWidth: '600px', lineHeight: 1.6 }}>
                        {t('sys.str_277')}</p>
                </div>
                <div style={{ fontSize: '80px', paddingLeft: '40px', opacity: 0.8 }}>ًں’¸</div>
            </div>

            {loading ? (
                <div style={{ textAlign: 'center', padding: '100px', fontSize: '20px', color: 'var(--text-muted)' }}>{t('sys.str_278')}</div>
            ) : (
                <>
                    {/* Link Generator Bar */}
                    <div style={{ background: 'var(--bg-card)', padding: '30px', borderRadius: '20px', marginTop: '40px', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}>
                        <h2 style={{ fontSize: '20px', margin: '0 0 20px 0', color: 'var(--text-main)' }}>{t('sys.str_279')}</h2>
                        <div style={{ display: 'flex', gap: '16px' }}>
                            <input 
                                type="text" 
                                readOnly 
                                value={referralLink} 
                                style={{ flex: 1, padding: '16px', borderRadius: '12px', border: '2px dashed var(--primary)', fontSize: '16px', background: 'var(--bg-app)', color: 'var(--primary)', fontWeight: 'bold' }}
                            />
                            <button 
                                onClick={handleCopy}
                                style={{ padding: '0 32px', background: 'var(--primary)', color: '#fff', border: 'none', borderRadius: '12px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer', transition: 'transform 0.1s' }}
                                onMouseDown={e => e.currentTarget.style.transform = 'scale(0.95)'}
                                onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
                            >
                                {t('sys.str_280')}</button>
                        </div>
                    </div>

                    {/* Stats Grid */}
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px', marginTop: '30px' }}>
                        
                        <div style={{ background: 'var(--bg-card)', padding: '30px', borderRadius: '20px', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: '20px', boxShadow: 'var(--shadow-sm)' }}>
                            <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'rgba(59,130,246,0.1)', color: '#3b82f6', display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '28px' }}>ًں–±ï¸ڈ</div>
                            <div>
                                <div style={{ fontSize: '14px', color: 'var(--text-muted)', fontWeight: '600' }}>{t('sys.str_281')}</div>
                                <div style={{ fontSize: '32px', fontWeight: '900', color: 'var(--text-main)', marginTop: '4px' }}>{stats.clicks}</div>
                            </div>
                        </div>

                        <div style={{ background: 'var(--bg-card)', padding: '30px', borderRadius: '20px', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: '20px', boxShadow: 'var(--shadow-sm)' }}>
                            <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'rgba(16,185,129,0.1)', color: '#10b981', display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '28px' }}>ًںڈھ</div>
                            <div>
                                <div style={{ fontSize: '14px', color: 'var(--text-muted)', fontWeight: '600' }}>{t('sys.str_282')}</div>
                                <div style={{ fontSize: '32px', fontWeight: '900', color: 'var(--text-main)', marginTop: '4px' }}>{stats.signups}</div>
                            </div>
                        </div>

                        <div style={{ background: 'var(--bg-card)', padding: '30px', borderRadius: '20px', border: '2px solid #10b981', display: 'flex', alignItems: 'center', gap: '20px', boxShadow: '0 10px 30px rgba(16,185,129,0.15)' }}>
                            <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: '#10b981', color: '#fff', display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '28px' }}>ًں’°</div>
                            <div>
                                <div style={{ fontSize: '14px', color: '#10b981', fontWeight: 'bold' }}>{t('sys.str_283')}</div>
                                <div style={{ fontSize: '32px', fontWeight: '900', color: 'var(--text-main)', marginTop: '4px' }}>{stats.earnings}</div>
                            </div>
                            <button 
                                onClick={() => alert(t('sys.str_288'))}
                                style={{ marginLeft: 'auto', padding: '10px 20px', background: '#10b981', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}>
                                {t('sys.str_284')}</button>
                        </div>

                    </div>
                    
                    {/* Guidelines */}
                    <div style={{ background: 'var(--bg-app)', padding: '30px', borderRadius: '20px', marginTop: '30px', fontSize: '14px', color: 'var(--text-muted)' }}>
                        <h3 style={{ color: 'var(--text-secondary)', marginBottom: '12px' }}>{t('sys.str_285')}</h3>
                        {t('sys.str_286')}</div>
                </>
            )}
        </div>
    );
}

