'use client';
import { useState, useEffect } from 'react';
import { Settings, Plus, Monitor, Truck, Building, Save, X } from 'lucide-react';

export default function FixedAssetsView() {
    const [assets, setAssets] = useState<any[]>([]);
    const [isLoaded, setIsLoaded] = useState(false);
    const [showModal, setShowModal] = useState(false);

    // Form State
    const [name, setName] = useState('');
    const [category, setCategory] = useState('IT_Equipment');
    const [purchasePrice, setPurchasePrice] = useState('0');
    const [usefulLife, setUsefulLife] = useState('5');
    const [salvageValue, setSalvageValue] = useState('0');

    useEffect(() => {
        fetchAssets();
    }, []);

    const fetchAssets = async () => {
        try {
            const res = await fetch('/api/finance/assets');
            if(res.ok) {
                const data = await res.json();
                setAssets(data);
            }
        } catch(e) {
            console.error(e);
        } finally {
            setIsLoaded(true);
        }
    };

    const handleSave = async () => {
        try {
            const res = await fetch('/api/finance/assets', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name, 
                    category, 
                    purchasePrice, 
                    usefulLifeYears: usefulLife, 
                    salvageValue
                })
            });
            if(res.ok) {
                setShowModal(false);
                fetchAssets();
            }
        } catch (e) {
            console.error("Error saving asset: ", e);
        }
    };

    const getIcon = (cat: string) => {
        if(cat === 'Vehicles') return <Truck size={20} className="text-blue-500" />;
        if(cat === 'Buildings') return <Building size={20} className="text-orange-500" />;
        return <Monitor size={20} className="text-emerald-500" />;
    };

    return (
        <div className="p-6 animate-in fade-in duration-500">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h1 className="text-2xl font-bold flex items-center gap-2">
                        <span>🏢</span> الأصول الثابتة وإهلاكاتها
                    </h1>
                    <p className="text-gray-500 mt-1 text-sm">
                        السجل الرئيسي للأصول، احتساب الإهلاك الآلي، ومراقبة القيمة الدفترية.
                    </p>
                </div>
                <button 
                    onClick={() => setShowModal(true)}
                    className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition"
                >
                    <Plus size={18} />
                    <span>إضافة أصل جديد</span>
                </button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="bg-card text-card-foreground p-6 rounded-xl border shadow-sm flex flex-col items-center justify-center">
                    <h3 className="text-sm text-gray-500 font-semibold mb-2">إجمالي الأصول</h3>
                    <p className="text-3xl font-bold">{assets.length}</p>
                </div>
                <div className="bg-card text-card-foreground p-6 rounded-xl border shadow-sm flex flex-col items-center justify-center">
                    <h3 className="text-sm text-gray-500 font-semibold mb-2">القيمة الدفترية المتبقية</h3>
                    <p className="text-3xl font-bold text-emerald-600">
                        {assets.reduce((sum, a) => sum + (a.currentValue || 0), 0).toLocaleString()} <span className="text-sm font-normal">ر.س</span>
                    </p>
                </div>
                <div className="bg-card text-card-foreground p-6 rounded-xl border shadow-sm flex flex-col items-center justify-center">
                    <h3 className="text-sm text-gray-500 font-semibold mb-2">الأصول المهلكة بالكامل</h3>
                    <p className="text-3xl font-bold text-red-500">
                        {assets.filter(a => a.status === 'DEPRECIATED').length}
                    </p>
                </div>
            </div>

            {/* Main Grid */}
            <div className="bg-card border rounded-xl shadow-sm overflow-hidden">
                {!isLoaded ? (
                    <div className="p-12 text-center text-gray-400">
                        <Settings className="animate-spin mx-auto mb-4" size={32} />
                        جاري تهيئة سجلات الأصول...
                    </div>
                ) : assets.length === 0 ? (
                    <div className="p-16 text-center text-gray-500">
                        <Building size={48} className="mx-auto mb-4 opacity-20" />
                        <h3 className="text-lg font-bold mb-2">لا توجد أصول مسجلة بعد</h3>
                        <p className="max-w-md mx-auto text-sm">قم بالضغط على "إضافة أصل جديد" لبناء سجل الشركة والممتلكات وحساب الميزانية.</p>
                    </div>
                ) : (
                    <table className="w-full text-sm text-right">
                        <thead className="bg-muted border-b">
                            <tr>
                                <th className="p-4 font-semibold">الأصل والتصنيف</th>
                                <th className="p-4 font-semibold">تاريخ الشراء</th>
                                <th className="p-4 font-semibold">القيمة الشرائية</th>
                                <th className="p-4 font-semibold">عمر الأصل (سنوات)</th>
                                <th className="p-4 font-semibold">قيمة الخردة</th>
                                <th className="p-4 font-semibold">القيمة الدفترية الحالية</th>
                                <th className="p-4 font-semibold">الحالة</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y text-gray-700">
                            {assets.map((asset) => (
                                <tr key={asset.id} className="hover:bg-muted/50 transition">
                                    <td className="p-4">
                                        <div className="flex items-center gap-3">
                                            {getIcon(asset.category)}
                                            <div>
                                                <div className="font-bold text-gray-900">{asset.name}</div>
                                                <div className="text-xs text-gray-500 font-mono mt-1">{asset.barcode}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="p-4">{new Date(asset.purchaseDate).toLocaleDateString('ar-SA')}</td>
                                    <td className="p-4 font-bold text-blue-600">{asset.purchasePrice.toLocaleString()} ر.س</td>
                                    <td className="p-4">{asset.usefulLifeYears} سنوات</td>
                                    <td className="p-4">{asset.salvageValue.toLocaleString()} ر.س</td>
                                    <td className="p-4 font-bold text-emerald-600">{asset.currentValue.toLocaleString()} ر.س</td>
                                    <td className="p-4">
                                        <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold">
                                            فعال
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            {/* Creation Modal */}
            {showModal && (
                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
                    <div className="bg-card w-full max-w-lg rounded-2xl shadow-xl overflow-hidden animate-in zoom-in-95 duration-200">
                        <div className="bg-primary p-4 text-white flex justify-between items-center">
                            <h2 className="font-bold text-lg">إضافة أصل ثابت جديد</h2>
                            <button onClick={() => setShowModal(false)} className="hover:bg-white/20 p-1 rounded"><X size={20}/></button>
                        </div>
                        <div className="p-6 space-y-4 text-right">
                            <div>
                                <label className="block text-sm font-semibold mb-1 text-gray-700">اسم ووصف الأصل</label>
                                <input value={name} onChange={e=>setName(e.target.value)} type="text" className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-primary" placeholder="مثال: سيارة توزيع إيسوزو دينا 2024" />
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-semibold mb-1 text-gray-700">تصنيف الأصل</label>
                                    <select value={category} onChange={e=>setCategory(e.target.value)} className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-primary">
                                        <option value="IT_Equipment">أجهزة ومعدات حاسب</option>
                                        <option value="Vehicles">سيارات وأسطول نقل</option>
                                        <option value="Buildings">مباني وحدات وعقارات</option>
                                        <option value="Machinery">آلات ومعدات ثقيلة</option>
                                        <option value="Furniture">أثاث وتجهيزات مكتبية</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-semibold mb-1 text-gray-700">القيمة الشرائية (التكلفة)</label>
                                    <input value={purchasePrice} onChange={e=>setPurchasePrice(e.target.value)} type="number" className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-primary" />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-semibold mb-1 text-gray-700">العمر الإنتاجي (بالسنوات)</label>
                                    <input value={usefulLife} onChange={e=>setUsefulLife(e.target.value)} type="number" className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-primary" />
                                </div>
                                <div>
                                    <label className="block text-sm font-semibold mb-1 text-gray-700">القيمة التخريدية المتوقعة (للبيع كخردة)</label>
                                    <input value={salvageValue} onChange={e=>setSalvageValue(e.target.value)} type="number" className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-primary" />
                                </div>
                            </div>
                            
                            <div className="pt-4 border-t mt-4 flex justify-end gap-3">
                                <button onClick={() => setShowModal(false)} className="px-5 py-2 rounded-lg bg-gray-100 text-gray-700 hover:bg-gray-200 transition font-semibold">إلغاء</button>
                                <button onClick={handleSave} className="px-5 py-2 rounded-lg bg-primary text-white hover:bg-primary/90 transition flex items-center gap-2 font-bold shadow-md">
                                    <Save size={18} /> حفظ واعتماد
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}