import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
    try {
        const zones = await prisma.restaurantZone.findMany({
            include: { tables: { include: { sessions: { where: { status: 'Active' } } } } }
        });
        return NextResponse.json({ success: true, zones });
    } catch (e: any) {
        return NextResponse.json({ success: false, error: e.message }, { status: 500 });
    }
}

export async function POST(req: Request) {
    try {
        const { action, payload } = await req.json();
        
        if (action === 'create_zone') {
            const zone = await prisma.restaurantZone.create({ data: { name: payload.name } });
            return NextResponse.json({ success: true, zone });
        }
        
        if (action === 'create_table') {
            const table = await prisma.restaurantTable.create({
                data: { name: payload.name, capacity: payload.capacity, zoneId: payload.zoneId }
            });
            return NextResponse.json({ success: true, table });
        }
        
        if (action === 'update_table_status') {
            const table = await prisma.restaurantTable.update({
                where: { id: payload.tableId },
                data: { status: payload.status }
            });
            return NextResponse.json({ success: true, table });
        }

        if (action === 'open_session') {
            await prisma.restaurantTable.update({
                where: { id: payload.tableId },
                data: { status: 'Occupied' }
            });
            const session = await prisma.restaurantSession.create({
                data: { tableId: payload.tableId, status: 'Active' }
            });
            return NextResponse.json({ success: true, session });
        }
        
        return NextResponse.json({ success: false, error: 'Invalid action' });
    } catch (e: any) {
        return NextResponse.json({ success: false, error: e.message }, { status: 500 });
    }
}
