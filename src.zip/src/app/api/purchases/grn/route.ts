import { NextRequest, NextResponse } from 'next/server';
import { getPrisma } from '@/lib/prisma';
import jwt from 'jsonwebtoken';
import { postGRN } from '@/lib/auto-journal';

export async function GET(req: Request) {
    const prisma = getPrisma(req as any);

    try {
        const authHeader = req.headers.get('Authorization');
        if (!authHeader) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        const decoded: any = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET || 'secret123');
        if (!decoded) return NextResponse.json({ error: 'Invalid Token' }, { status: 401 });

        const grns = await prisma.goodsReceiptNote.findMany({
            include: {
                supplier: { select: { name: true } },
                order: { select: { orderNo: true } },
                receiver: { select: { fullName: true } },
                stock: { select: { name: true } },
                details: {
                    include: { product: { select: { name: true, unit: true } } }
                }
            },
            orderBy: { id: 'desc' }
        });

        return NextResponse.json(grns);
    } catch (e) {
        console.error(e);
        return NextResponse.json({ error: 'Server Error' }, { status: 500 });
    }
}

export async function POST(req: Request) {
    const prisma = getPrisma(req as any);

    try {
        const authHeader = req.headers.get('Authorization');
        if (!authHeader) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        const decoded: any = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET || 'secret123');
        if (!decoded) return NextResponse.json({ error: 'Invalid Token' }, { status: 401 });

        const body = await req.json();
        const { supplierId, orderId, stockId, notes, items } = body;

        const agg = await prisma.goodsReceiptNote.aggregate({ _max: { grnNo: true } });
        const nextNo = (agg._max.grnNo || 3000) + 1;

        const grn = await prisma.$transaction(async (tx) => {
            const newGrn = await tx.goodsReceiptNote.create({
                data: {
                    grnNo: nextNo,
                    supplierId: supplierId ? parseInt(supplierId) : null,
                    orderId: orderId ? parseInt(orderId) : null,
                    stockId: stockId ? parseInt(stockId) : 1,
                    notes: notes,
                    receivedBy: decoded.userId,
                    status: 'received',
                    details: {
                        create: items.map((i: any) => ({
                            productId: parseInt(i.productId),
                            productName: i.productName,
                            quantity: parseFloat(i.quantity),
                            acceptedQty: parseFloat(i.acceptedQty) || parseFloat(i.quantity),
                            rejectedQty: parseFloat(i.rejectedQty) || 0
                        }))
                    }
                }
            });

            let totalGrnCost = 0;

            for (const item of items) {
                const accepted = parseFloat(item.acceptedQty) || parseFloat(item.quantity);
                if (accepted > 0) {
                    const productObj = await tx.product.findUnique({ where: { id: parseInt(item.productId) } });
                    totalGrnCost += accepted * (productObj?.buyPrice || productObj?.buyPrice || 0);

                    await tx.product.update({
                        where: { id: parseInt(item.productId) },
                        data: { currentStock: { increment: accepted } }
                    });

                    await tx.stockMovement.create({
                        data: {
                            productId: parseInt(item.productId),
                            stockId: stockId ? parseInt(stockId) : 1,
                            type: 'in',
                            quantity: accepted,
                            referenceType: 'GRN',
                            referenceId: newGrn.id,
                            userId: decoded.userId,
                            notes: 'استلام بضاعة سند إدخال رقم ' + nextNo
                        }
                    });
                }
            }

            if (totalGrnCost > 0) {
                try {
                    await postGRN({
                        grnNo: newGrn.grnNo,
                        totalCost: totalGrnCost,
                        supplierName: 'مورد', // Could fetch from tx.supplier if needed
                        userId: decoded.userId
                    });
                } catch (je) {
                    console.error("Auto Journal Error (GRN):", je);
                }
            }

            return newGrn;
        });

        return NextResponse.json(grn);
    } catch (e) {
        console.error(e);
        return NextResponse.json({ error: 'Server Error' }, { status: 500 });
    }
}
