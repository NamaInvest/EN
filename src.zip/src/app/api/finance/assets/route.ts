import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const assets = await prisma.asset.findMany({
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(assets);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch assets' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json();
    const asset = await prisma.asset.create({
      data: {
        name: data.name,
        barcode: data.barcode || `AST-${Date.now()}`,
        category: data.category,
        purchasePrice: parseFloat(data.purchasePrice),
        currentValue: parseFloat(data.purchasePrice), // Initial current value is purchase price
        usefulLifeYears: parseInt(data.usefulLifeYears),
        salvageValue: parseFloat(data.salvageValue || 0),
        depreciationType: data.depreciationType || 'STRAIGHT_LINE',
        status: 'ACTIVE',
        location: data.location || ''
      }
    });
    return NextResponse.json(asset);
  } catch (error) {
    console.error("Asset Creation Error:", error);
    return NextResponse.json({ error: 'Failed to create asset' }, { status: 500 });
  }
}
