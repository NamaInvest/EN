'use client';
import { useState, useEffect } from 'react';

interface Transfer { id: number; transferNo: number; date: string; fromStockId: number; toStockId: number; notes: string; details: { productName: string; quantity: number }[] }
interface Stock { id: number; name: string }

export default function StockTransfersPage() {
    const [transfers, setTransfers] = useState<Transfer[]>([]);
    const [stocks, setStocks] = useState<Stock[]>([]);
    const [expanded, setExpanded] = useState<number | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => { load(); loadStocks(); }, []);
    const load = async () => { setLoading(true); try { const r = await fetch('/api/stock-transfers'); if (r.ok) setTransfers(await r.json()); } catch (e) { console.error(e); } setLoading(false); };
    const loadStocks = async () => { try { const r = await fetch('/api/products'); if (r.ok) { /* stocks from settings or hardcoded */ setStocks([{ id: 1, name: 'المخزن الرئيسي' }, { id: 2, name: 'المخزن الفرعي' }]); } } catch (e) { console.error(e); } };

    const getStockName = (id: number) => stocks.find(s => s.id === id)?.name || `مخزن #${id}`;

    return (<><div className="page-header"><h1 className="page-title">🔀 تحويلات المخزون</h1></div>
        <div className="page-content animate-fade-in">
            <div className="toolbar"><span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>{transfers.length} تحويل</span><div className="toolbar-spacer" /></div>
            <div className="card">
                {loading ? <div className="empty-state"><div className="empty-state-text">جاري التحميل...</div></div> :
                    transfers.length === 0 ? <div className="empty-state"><div className="empty-state-icon">🔀</div><div className="empty-state-text">لا توجد تحويلات مخزون</div></div> :
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>{transfers.map(t => (
                            <div key={t.id} className="card" style={{ padding: '12px', cursor: 'pointer' }} onClick={() => setExpanded(expanded === t.id ? null : t.id)}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                                    <span style={{ fontFamily: 'monospace', color: 'var(--primary)' }}>#{t.transferNo}</span>
                                    <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{new Date(t.date).toLocaleDateString('ar-SA')}</span>
                                    <span style={{ fontSize: '12px' }}>{getStockName(t.fromStockId)} ← {getStockName(t.toStockId)}</span>
                                    <div className="toolbar-spacer" />
                                    <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{t.details?.length || 0} صنف</span>
                                </div>
                                {expanded === t.id && t.details && <table style={{ width: '100%', marginTop: '10px', borderCollapse: 'collapse' }}>
                                    <thead><tr style={{ background: 'rgba(108,99,255,0.05)', fontSize: '12px' }}><th style={{ padding: '6px', textAlign: 'right' }}>المنتج</th><th style={{ padding: '6px', textAlign: 'center' }}>الكمية</th></tr></thead>
                                    <tbody>{t.details.map((d, i) => <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}><td style={{ padding: '6px', fontSize: '12px' }}>{d.productName}</td><td style={{ padding: '6px', textAlign: 'center', fontFamily: 'monospace' }}>{d.quantity}</td></tr>)}</tbody>
                                </table>}
                            </div>
                        ))}</div>}
            </div>
        </div></>);
}
