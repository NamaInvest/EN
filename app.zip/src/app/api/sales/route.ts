import { NextResponse, NextRequest } from 'next/server';
import prisma from '@/lib/prisma';
import { getUserFromRequest, hasPermission } from '@/lib/auth';
import { postSalesInvoice } from '@/lib/auto-journal';
import { initializeZatca, generateZatcaQR, getQrCodeContent, generateZATCAXml } from '@/lib/zatca';

export async function GET(request: Request) {
    try {
        const { searchParams } = new URL(request.url);
        const from = searchParams.get('from');
        const to = searchParams.get('to');

        const where: Record<string, unknown> = {};
        if (from || to) {
            where.date = {};
            if (from) (where.date as Record<string, unknown>).gte = new Date(from);
            if (to) (where.date as Record<string, unknown>).lte = new Date(to + 'T23:59:59');
        }

        const invoices = await prisma.salesInvoice.findMany({
            where,
            include: { customer: true, details: true, user: { select: { id: true, username: true, fullName: true, role: true, phone: true } } },
            orderBy: { id: 'desc' },
        });
        return NextResponse.json(invoices);
    } catch (error) {
        console.error('Sales GET error:', error);
        return NextResponse.json([], { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const body = await request.json();

        // Get next invoice number
        const lastInvoice = await prisma.salesInvoice.findFirst({
            orderBy: { invoiceNo: 'desc' },
        });
        const invoiceNo = (lastInvoice?.invoiceNo || 0) + 1;

        // Calculate totals
        let subtotal = 0;
        const items = body.items || [];
        for (const item of items) {
            const itemTotal = (item.quantity || 1) * (item.price || 0);
            const itemDiscount = itemTotal * ((item.discountRate || 0) / 100);
            subtotal += itemTotal - itemDiscount;
        }

        const discountRate = parseFloat(body.discountRate) || 0;
        const discountValue = subtotal * (discountRate / 100);
        const afterDiscount = subtotal - discountValue;
        const taxValue = afterDiscount * 0.15;
        const total = afterDiscount + taxValue;
        const paid = parseFloat(body.paid) || total;
        const remaining = total - paid;

        const invoice = await prisma.salesInvoice.create({
            data: {
                invoiceNo,
                customerId: body.customerId ? parseInt(body.customerId) : null,
                stockId: body.stockId ? parseInt(body.stockId) : 1,
                subtotal,
                discountRate,
                discountValue,
                taxValue,
                total,
                paid,
                remaining,
                paymentType: body.paymentType || 'cash',
                status: remaining > 0 ? 'pending' : 'completed',
                userId: body.userId || null,
                notes: body.notes || null,
                details: {
                    create: items.map((item: Record<string, unknown>) => {
                        const qty = parseFloat(item.quantity as string) || 1;
                        const price = parseFloat(item.price as string) || 0;
                        const dRate = parseFloat(item.discountRate as string) || 0;
                        const itemSubtotal = qty * price;
                        const dValue = itemSubtotal * (dRate / 100);
                        const afterD = itemSubtotal - dValue;
                        const tax = afterD * 0.15;
                        return {
                            productId: parseInt(item.productId as string),
                            productName: item.productName as string || '',
                            quantity: qty,
                            price,
                            discountRate: dRate,
                            discountValue: dValue,
                            taxRate: 15,
                            taxValue: tax,
                            total: afterD + tax,
                        };
                    }),
                },
            },
            include: { details: true, customer: true },
        });

        // Update stock
        for (const item of items) {
            await prisma.product.update({
                where: { id: parseInt(item.productId) },
                data: { currentStock: { decrement: parseFloat(item.quantity) || 1 } },
            });
        }

        // Treasury entry
        if (paid > 0) {
            await prisma.treasury.create({
                data: {
                    type: 'in',
                    amount: paid,
                    description: `فاتورة مبيعات #${invoiceNo}`,
                    referenceType: 'sale',
                    referenceId: invoice.id,
                    userId: body.userId || null,
                },
            });
        }

        // Auto-journal entry (double-entry accounting)
        try {
            await postSalesInvoice({
                invoiceNo,
                subtotal: afterDiscount,
                taxValue,
                total,
                paymentType: body.paymentType || 'cash',
                userId: body.userId,
                discountValue,
                date: new Date().toISOString().split('T')[0],
            });
        } catch (journalErr) {
            console.warn('Auto-journal for sale skipped:', journalErr);
        }

        // ZATCA Phase 2 QR code generation
        let zatcaQR = '';
        try {
            const zatcaSettings = await prisma.setting.findMany({
                where: { key: { in: ['company_name', 'tax_number', 'zatca_crn', 'zatca_street', 'zatca_building', 'zatca_district', 'zatca_city', 'zatca_postal_code', 'zatca_private_key', 'zatca_certificate', 'zatca_enabled', 'zatca_production_token', 'zatca_production_secret', 'zatca_environment'] } }
            });
            const s: Record<string, string> = {};
            zatcaSettings.forEach(st => { s[st.key] = st.value ?? ''; });

            if (s['zatca_enabled'] === '1' && s['company_name'] && s['tax_number']) {
                // Use production certificate (decoded from ZATCA API's base64) if available, else fallback to stored certificate
                let certificateBase64 = s['zatca_certificate'] || undefined;
                if (s['zatca_production_token']) {
                    // ZATCA API returns binarySecurityToken as base64(PEM_body) — decode outer base64
                    certificateBase64 = Buffer.from(s['zatca_production_token'], 'base64').toString('ascii');
                }

                initializeZatca({
                    sellerName: s['company_name'],
                    sellerTRN: s['tax_number'],
                    privateKeyBase64: s['zatca_private_key'] || undefined,
                    certificateBase64,
                    supplier: {
                        companyID: s['zatca_crn'] || '',
                        registrationName: s['tax_number'],
                        address: {
                            streetName: s['zatca_street'] || '',
                            buildingNumber: s['zatca_building'] || '',
                            citySubdivisionName: s['zatca_district'] || '',
                            cityName: s['zatca_city'] || '',
                            postalZone: s['zatca_postal_code'] || '',
                        }
                    }
                });

                const now = new Date();
                const qrData = generateZatcaQR({
                    invoiceLines: items.map((item: Record<string, unknown>, idx: number) => ({
                        id: String(idx + 1),
                        quantity: String(item.quantity || 1),
                        unitCode: 'PCE',
                        lineExtensionAmount: String(((parseFloat(item.quantity as string) || 1) * (parseFloat(item.price as string) || 0)).toFixed(2)),
                        itemName: (item.productName as string) || 'منتج',
                        taxPercent: '15',
                    })),
                    issueDate: now.toISOString().split('T')[0],
                    issueTime: now.toTimeString().split(' ')[0],
                    invoiceUuid: crypto.randomUUID(),
                    invoiceNumber: `INV${String(invoiceNo).padStart(6, '0')}`,
                    totalWithVat: total.toFixed(2),
                    totalVat: taxValue.toFixed(2),
                });
                zatcaQR = getQrCodeContent(qrData);

                // Auto-report to Fatoora platform if production CSID is configured
                if (s['zatca_production_token'] && s['zatca_production_secret']) {
                    try {
                        const { reportInvoice: fatooraReport } = await import('@/lib/zatca-fatoora');
                        const xmlString = generateZATCAXml({
                            profileID: 'reporting:1.0', id: `INV${String(invoiceNo).padStart(6, '0')}`,
                            uuid: qrData.invoiceData.uuid, issueDate: qrData.issueDate,
                            issueTime: now.toTimeString().split(' ')[0], invoiceTypeCode: '388',
                            invoiceTypeName: '0200000', note: 'فاتورة مبيعات', currencyCode: 'SAR',
                            taxCurrencyCode: 'SAR', supplier: qrData.invoiceData.supplier,
                            customer: qrData.invoiceData.customer, invoiceLines: qrData.invoiceData.invoiceLines,
                            taxAmount: taxValue.toFixed(2), totalAmount: total.toFixed(2),
                        });
                        const env = (s['zatca_environment'] as 'simulation' | 'production') || 'production';
                        await fatooraReport({
                            binarySecurityToken: s['zatca_production_token'],
                            secret: s['zatca_production_secret'],
                            invoiceHash: qrData.invoiceHash,
                            uuid: qrData.invoiceData.uuid,
                            invoiceBase64: Buffer.from(xmlString).toString('base64'),
                            environment: env,
                        });
                        console.log(`✅ Invoice ${invoiceNo} reported to Fatoora`);
                    } catch (fatooraErr) {
                        console.warn('Fatoora reporting skipped:', fatooraErr);
                    }
                }
            }
        } catch (zatcaErr) {
            console.warn('ZATCA QR generation skipped:', zatcaErr);
        }

        return NextResponse.json({ ...invoice, zatcaQR }, { status: 201 });
    } catch (error) {
        console.error('Sales create error:', error);
        return NextResponse.json({ error: 'فشل في إنشاء الفاتورة' }, { status: 500 });
    }
}

export async function DELETE(request: NextRequest) {
    try {
        const auth = getUserFromRequest(request);
        if (!auth) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

        const { searchParams } = new URL(request.url);
        const action = searchParams.get('action');
        const id = Number(searchParams.get('id'));

        // Bulk delete all sales invoices
        if (action === 'delete_all') {
            const allowed = await hasPermission(auth.userId, 'delete_all_sales');
            if (!allowed) return NextResponse.json({ error: 'غير مصرح - تحتاج صلاحية حذف كل الفواتير' }, { status: 403 });

            // Delete all details, treasury entries, then invoices
            await prisma.salesInvoiceDetail.deleteMany({});
            await prisma.treasury.deleteMany({ where: { referenceType: 'sale' } });
            const result = await prisma.salesInvoice.deleteMany({});
            return NextResponse.json({ success: true, message: `تم حذف ${result.count} فاتورة مبيعات` });
        }

        // Single invoice delete
        const allowed = await hasPermission(auth.userId, 'delete_invoices');
        if (!allowed) return NextResponse.json({ error: 'غير مصرح - تحتاج صلاحية حذف الفواتير' }, { status: 403 });

        if (!id) return NextResponse.json({ error: 'معرف الفاتورة مطلوب' }, { status: 400 });

        const invoice = await prisma.salesInvoice.findUnique({ where: { id }, include: { details: true } });
        if (!invoice) return NextResponse.json({ error: 'الفاتورة غير موجودة' }, { status: 404 });

        // Reverse stock (re-increment what was sold)
        for (const detail of invoice.details) {
            await prisma.product.update({
                where: { id: detail.productId },
                data: { currentStock: { increment: detail.quantity } },
            });
        }

        // Remove related treasury entries
        await prisma.treasury.deleteMany({ where: { referenceType: 'sale', referenceId: id } });

        // Delete invoice (cascade deletes details)
        await prisma.salesInvoice.delete({ where: { id } });

        return NextResponse.json({ success: true, message: 'تم حذف الفاتورة بنجاح' });
    } catch (error) {
        console.error('Sales DELETE error:', error);
        return NextResponse.json({ error: 'فشل في حذف الفاتورة' }, { status: 500 });
    }
}
