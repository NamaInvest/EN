import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET() {
    try {
        const returns = await prisma.salesReturn.findMany({ orderBy: { id: 'desc' } });
        return NextResponse.json(returns);
    } catch (e) { console.error(e); return NextResponse.json([], { status: 500 }); }
}

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const last = await prisma.salesReturn.findFirst({ orderBy: { returnNo: 'desc' } });
        const returnNo = (last?.returnNo || 0) + 1;
        const subtotal = parseFloat(body.subtotal) || 0;
        const taxValue = subtotal * 0.15;

        const ret = await prisma.salesReturn.create({
            data: {
                returnNo, originalInvoiceId: body.originalInvoiceId || null,
                customerId: body.customerId || null, subtotal, taxValue, total: subtotal + taxValue,
                userId: body.userId || null, notes: body.notes || null,
            },
        });

        // Treasury out
        if (ret.total > 0) {
            await prisma.treasury.create({ data: { type: 'out', amount: ret.total, description: `مرتجع مبيعات #${returnNo}`, referenceType: 'sales_return', referenceId: ret.id, userId: body.userId || null } });
        }

        return NextResponse.json(ret, { status: 201 });
    } catch (e) { console.error(e); return NextResponse.json({ error: 'فشل' }, { status: 500 }); }
}
