#!/usr/bin/env node
/**
 * ZATCA Invoice Signing Helper Script
 * Called by the app as a subprocess to avoid Next.js bundling issues with crypto
 * 
 * Supports: invoice (388), credit note (381), debit note (383)
 */

const fs = require('fs');

async function main() {
    const inputFile = process.argv[2];
    const outputFile = process.argv[3];

    if (!inputFile || !outputFile) {
        console.error('Usage: node zatca-sign-invoice.js <input.json> <output.json>');
        process.exit(1);
    }

    const input = JSON.parse(fs.readFileSync(inputFile, 'utf-8'));

    const { ZATCASimplifiedTaxInvoice, ZATCAPaymentMethods } = require('zatca-xml-js');
    const { generateSignedXMLString } = require('zatca-xml-js/lib/zatca/signing');

    // Build cancelation info for credit/debit notes
    // SDK requires: cancelation_type, canceled_invoice_number, payment_method, reason
    let cancelation = undefined;
    if (input.invoiceType === '381') {
        cancelation = {
            cancelation_type: '381',
            canceled_invoice_number: input.canceledInvoiceNumber || 'INV-COMP-001',
            payment_method: '10',
            reason: 'Credit note',
        };
    } else if (input.invoiceType === '383') {
        cancelation = {
            cancelation_type: '383',
            canceled_invoice_number: input.canceledInvoiceNumber || 'INV-COMP-001',
            payment_method: '10',
            reason: 'Debit note',
        };
    }

    // Create invoice
    const invoice = new ZATCASimplifiedTaxInvoice({
        props: {
            egs_info: input.egsInfo,
            invoice_counter_number: input.invoiceCounterNumber || 1,
            invoice_serial_number: input.invoiceSerialNumber || 'INV-001',
            issue_date: input.issueDate,
            issue_time: input.issueTime,
            previous_invoice_hash: input.previousInvoiceHash,
            line_items: input.lineItems || [{
                id: '1',
                name: 'Test Product',
                quantity: 1,
                tax_exclusive_price: 100,
                VAT_percent: 0.15,
                other_taxes: [],
                discounts: [],
            }],
            cancelation: cancelation,
        },
        payment_method: input.paymentMethod || ZATCAPaymentMethods.CASH,
    });

    // Sign
    const { signed_invoice_string, invoice_hash, qr } = generateSignedXMLString({
        invoice_xml: invoice.invoice_xml,
        certificate_string: input.certificate,
        private_key_string: input.privateKey,
    });

    // Write output
    fs.writeFileSync(outputFile, JSON.stringify({
        signed_invoice_string,
        invoice_hash,
        qr,
        uuid: input.egsInfo.uuid,
    }));

    console.log('OK');
}

main().catch(e => {
    console.error(e.message);
    process.exit(1);
});
